import NewVerificationFrom from "@/components/auth/new-verification-form"

const NewVerificationPage = () => {
  return (
    <NewVerificationFrom/>
  )
}

export default NewVerificationPage