import RegisterForm from "@/components/auth/register-form";

const RegisterPage = () => {
  return (
        <RegisterForm/>
    );
};

export default RegisterPage;
