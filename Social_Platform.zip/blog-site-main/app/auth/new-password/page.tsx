import NewPasswordForm from "@/components/auth/new-password-form";

const NewPassword = () => {
  return (
    <NewPasswordForm/>
  )
}

export default NewPassword